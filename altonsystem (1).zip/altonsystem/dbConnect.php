<?php
$conn = mysqli_connect("localhost","root","","reservation") OR DIE (mysql_error());


?>



